package ui;
import java.util.Scanner;
import core.MCLEMKEConnect4;
import core.MCLEMKEConnect4ComputerPlayer;

/**
 * @author Marcus Lemke
 * SER 216
 * 
 * Description:
 * This program uses the Connect 4 game logic from the core package and runs the game.
 * 
 * This program also uses 3 try catch loops to handle exceptions. These exceptions
 * are triggered if the player or computer use an invalid input for their piece placement. 
 * They are then required to re-enter a new value until their input is valid.
 */
public class MCLEMKEConnect4TextConsole 
{

		static MCLEMKEConnect4 game = new MCLEMKEConnect4();
		static MCLEMKEConnect4ComputerPlayer CPU = new MCLEMKEConnect4ComputerPlayer();
		
		static Scanner input = new Scanner(System.in);
	
	/**
	 * This method is used to create a different game for either UI or GUI.
	 * @param Connect4Game
	 */
	public MCLEMKEConnect4TextConsole(MCLEMKEConnect4 Connect4Game)
	{
			this.game = Connect4Game;
	}
	
	
	/**
	 * This method is used to start and keep track of the game being played.
	 */
	public static void startGame()
	{		
		System.out.println("WELCOME TO CONNECT 4!");
		System.out.println("---------------------");
		
		System.out.println("Do you want to play against another player or against the computer? "
				+ "Enter P for Player or Enter C for Computer: ");
		
		boolean changeTurn = true;
		
		String key = input.next();
		
		int in = 1;
		
		while (in == 1)
		{
			if (key.equals("c"))
			{
				in = 0;
			}
			
			else if (key.equals("p"))
			{
				in = 0;
			}
			
			else
			{
				System.out.print("Invalid Input. Must enter P to play against another player or C to play against the computer. "
						+ "Please enter your selection: ");
				key = input.next();
			}
		}
		
		if (null != key) switch (key)
		{
			case "p":
				System.out.println("You've Chosen Two Player Mode!");
		
			do
			{
				changeTurn = !changeTurn;
				System.out.println();
				char gamer;
			
				if(changeTurn)
				{
					gamer = 'O';
				}
			
				else
				{
					gamer = 'X';
				}
			
				game.printRack();
				
				System.out.println();
				System.out.print("PLAYER " + gamer + ": It is your turn! Please choose a column (1-7) - ");
			
				boolean value = false;
			
				while(!value)
				{
					try
					{
						value = game.dropPiece(gamer, input.nextInt());
					
						if(!value)
						{
							System.out.println("Your column choice is either invalid or full");
							System.out.print("Please input another value: ");
						}	
					}
				
					catch(Exception W)
					{
						System.out.println("The value entered is invalid.");
						System.out.println("Please input another value: ");
						input.nextLine();
					}
				}
			
				System.out.println();
			
			}while(!game.gameOver() && !game.winnerFound());
		
			game.printRack();
		
			if(game.winnerFound())
			{
				System.out.printf("PLAYER %s HAS WON THE GAME OF CONNECT 4!", (changeTurn? "O" : "X"));
				System.out.println();
			}
		
			else
			{
				System.out.println("THE GAME IS A DRAW! GAME OVER!");
			}
		
			input.close();
		
			
			case "c":
				System.out.println("You've Chosen Single Player Mode!");
		
			do
			{
				changeTurn = !changeTurn;
				System.out.println();
				char gamer;
			
				if(changeTurn)
				{
					gamer = 'O';
				}
			
				else
				{
					gamer = 'X';
				}
			
				switch(gamer)
				{
					case 'X':
				
						game.printRack();
				
						System.out.println();
						System.out.print("PLAYER " + gamer + ": It is your turn! Please choose a column (1-7) - ");
			
						boolean value = false;
			
						while(!value)
						{
							try
							{
								value = game.dropPiece(gamer, input.nextInt());
					
								if(!value)
								{
									System.out.println("Your column choice is either invalid or full");
									System.out.print("Please input another value: ");
								}	
							}
				
							catch(Exception W)
							{
								System.out.println("The value entered is invalid.");
								System.out.println("Please input another value: ");
								input.nextLine();
							}
						}
			
						System.out.println();
						break;
				
					case 'O':
				
						game.printRack();
						
						value = false;
						
						while(!value)
						{
							try
							{
								int cpuMove = CPU.MCLEMKEConnect4ComputerPlayerPlay();
								System.out.println("COMPUTER CHOOSES COLUMN #" + cpuMove);
								value = game.dropPiece(gamer, cpuMove);
							
								if(!value)
								{
								System.out.println("Computers column choice is either invalid or full");
								}	
							}
				
							catch(Exception W)
							{
								System.out.println("Computer choice is invalid. Computer choosing again.");
								int cpuMove = CPU.MCLEMKEConnect4ComputerPlayerPlay();
							}
						}
				
					break;
				}
				
			}while(!game.gameOver() && !game.winnerFound());
		
			game.printRack();
		
			if(game.winnerFound())
			{
				System.out.printf("PLAYER %s HAS WON THE GAME OF CONNECT 4!", (changeTurn? "O" : "X"));
				System.out.println();
			}
		
			else
			{
				System.out.println("THE GAME IS A DRAW! GAME OVER!");
			}
		
			input.close();
				
		}	
	}
}







