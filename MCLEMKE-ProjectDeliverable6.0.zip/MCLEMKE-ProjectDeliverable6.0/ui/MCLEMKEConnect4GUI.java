package ui;

import core.MCLEMKEConnect4Client;
import core.MCLEMKEConnect4;
import core.MCLEMKEGameLogicConst;
import ui.MCLEMKEConnect4TextConsole;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Point2D;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.effect.Light;
import javafx.scene.effect.Lighting;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/**
 * @author Marcus Lemke
 * SER 216
 * 
 * Description:
 * This program uses the Connect 4 game logic from the core package and Connect 4 Text console
 * and runs the game as an interactive graphic window.
 */

public class MCLEMKEConnect4GUI extends Application implements MCLEMKEGameLogicConst
{

	MCLEMKEConnect4 game = new MCLEMKEConnect4();

	private boolean redTurn = false;
	boolean cpuGame = false;
	private Stage window;
	private Scene mainMenu;
	private Pane pane = new Pane();
	private Piece[][] connect4Grid = new Piece[COLUMN][ROW];
	private List<Piece> cpuMoves = new ArrayList<>();


	/**
	 * This is used to create the start of the connect 4 menu.
	 */
	private class Piece extends Circle 
	{
		boolean red;

		public Piece(boolean red) 
		{
			super(GAME_SIZE / 2, red ? Color.BLACK : Color.RED);
			this.red = red;
			setCenterX(GAME_SIZE / 2);
			setCenterY(GAME_SIZE / 2);
		}
	}

	
	/**
	 * This method is used to create and display the options on how you want to play the game. 
	 * @param stage
	 */
	public void startWindow(Stage stage) 
	{
		window = stage;
		
		Label menu = new Label("Choose the method to play Connect 4!");
		menu.setFont(new Font("Times New Roman", 24));
		
		Button online = new Button("Online");
		online.setStyle("-fx-font: 20 Times New Roman; -fx-base: lightgrey;");
		online.setOnMouseClicked(e -> {online(window);});
		
		Button local = new Button("Local");
		local.setStyle("-fx-font: 20 Times New Roman; -fx-base: lightgrey;");
		local.setOnMouseClicked(e -> {startMenu(window);});

		HBox lBox = new HBox(8);
		lBox.getChildren().add(menu);
		lBox.setPadding(new Insets(10, 10, 10, 10));
		lBox.setAlignment(Pos.CENTER);

		HBox button = new HBox(8);
		button.getChildren().addAll(online, local);
		button.setPadding(new Insets(10, 10, 10, 10));
		button.setAlignment(Pos.CENTER);

		BorderPane but = new BorderPane();
		but.setStyle("-fx-background-color: white");
		but.setTop(lBox);
		but.setCenter(button);

		mainMenu = new Scene(but, 400, 150);
		window.setScene(mainMenu);
		window.setTitle("Connect 4 Game");
		Stage newStage = (Stage) window.getScene().getWindow();
		window.show();
	}

	/**
	 * Launches the online game.
	 * @param stage
	 */
	
	public void online(Stage stage)
	{
		System.out.println("Playing Online!");
		MCLEMKEConnect4Client c = new MCLEMKEConnect4Client();
		String[] g = {};
		c.main(g);
	}
	
	
	/**
	 * Main menu for the GUI Game.
	 * @param stage
	 */
	public void startMenu(Stage stage) 
	{
		window = stage;

		Label newLabel = new Label("How Would you like to play?");
		newLabel.setFont(new Font("Times New Roman", 24));
		Button guiButton = new Button("GUI");
		guiButton.setStyle("-fx-font: 20 Times New Roman; -fx-base: lightgrey;");
		guiButton.setOnMouseClicked(e -> {guiMenu(window);});
		
		Button conButton = new Button("Console");
		conButton.setStyle("-fx-font: 20 Times New Roman; -fx-base: lightgrey;");
		conButton.setOnMouseClicked(e -> {
			MCLEMKEConnect4TextConsole startConGame = new MCLEMKEConnect4TextConsole(new MCLEMKEConnect4());
			stage.close();
			startConGame.startGame();});
		
		HBox lBox = new HBox(8);
		lBox.getChildren().add(newLabel);
		lBox.setPadding(new Insets(10, 10, 10, 10));
		lBox.setAlignment(Pos.CENTER);

		HBox button = new HBox(8);
		button.getChildren().addAll(guiButton, conButton);
		button.setPadding(new Insets(10, 10, 10, 10));
		button.setAlignment(Pos.CENTER);

		BorderPane but = new BorderPane();
		but.setStyle("-fx-background-color: white");
		but.setTop(lBox);
		but.setCenter(button);

		mainMenu = new Scene(but, 400, 150);
		window.setScene(mainMenu);
		window.setTitle("Connect 4 Game");
		Stage newStage = (Stage) window.getScene().getWindow();
		window.show();
	}
	
	
	/**
	 * Main menu for the GUI Game.
	 * @param stage
	 */
	private void guiMenu(Stage stage)
	{
		window = stage;

		Label newLabel = new Label("       What mode do you want to play?");
		newLabel.setFont(new Font("Times New Roman", 24));
		HBox labelBox = new HBox(8);
		labelBox.getChildren().add(newLabel);
		labelBox.setPadding(new Insets(10, 10, 10, 10));
		labelBox.setAlignment(Pos.CENTER);
	
		Button singlePlayButton = new Button("Single Player");
		singlePlayButton.setStyle("-fx-font: 20 Times New Roman; -fx-base: lightgrey;");
		
		Button multiPlayButton = new Button("Multiplayer");
		multiPlayButton.setStyle("-fx-font: 20 Times New Roman; -fx-base: lightgrey;");

		HBox localButton = new HBox(8);
		localButton.getChildren().addAll(singlePlayButton, multiPlayButton);
		localButton.setPadding(new Insets(10, 10, 10, 10));
		localButton.setAlignment(Pos.CENTER);

		BorderPane buttonPane = new BorderPane();
		buttonPane.setStyle("-fx-background-color: white");
		buttonPane.setTop(newLabel);
		buttonPane.setCenter(localButton);

		mainMenu = new Scene(buttonPane, 400, 150);
		window.setScene(mainMenu);
		window.setTitle("Connect 4 Game");

		Stage newStage = (Stage) window.getScene().getWindow();
		window.show();

		multiPlayButton.setOnAction(e -> multiplayer(new Stage()));

		singlePlayButton.setOnAction(e -> {
			cpuGame = true;
			singleplayer(new Stage());
		});
	}

	
	/**
	 * Method used to play two player Connect 4.
	 * @param stage
	 */
	private void multiplayer(Stage stage) 
	{
		stage.setOnCloseRequest(e -> {
			e.consume();
			closeGame();
		});
		
		stage.setTitle("Multiplayer");
		stage.setScene(new Scene(board()));
		stage.getScene().getWindow();
		stage.show();
		
		window.close();
		
		System.out.println((redTurn ? "BLACK Player's " : "RED Player's ") + " Turn");
	}


	/**
	 * Method used to play Connect 4 against the Computer.
	 * @param stage
	 */
	private void singleplayer(Stage stage) 
	{
		stage.setOnCloseRequest(e -> {
			e.consume();
			closeGame();
		});
		
		stage.setTitle("Single Player");
		stage.setScene(new Scene(board()));
		stage.getScene().getWindow();
		stage.show();
		
		window.close();
		
		System.out.println((redTurn ? "BLACK Player's " : "RED Player's ") + "Turn");
	}

	
	/**
	 * Method used to display the connect 4 game grid. 
	 * @return rPane
	 */
	private Parent board() 
	{

		Pane rPane = new Pane();
		rPane.getChildren().add(pane);
		Shape gridShape = createConnect4Grid();
		rPane.getChildren().add(gridShape);
		rPane.getChildren().addAll(grid());

		return rPane;
	}


	/**
	 * Method used to show the user what column they are using.
	 * @return list
	 */
	public List<Rectangle> grid() 
	{
		List<Rectangle> list = new ArrayList<>();

		for (int m = 0; m < COLUMN; m++) 
		{
			Rectangle rect = new Rectangle(GAME_SIZE * (ROW + 1), GAME_SIZE);
			rect.setTranslateX(m * (GAME_SIZE + 6) + GAME_SIZE / 3);
			rect.setFill(Color.TRANSPARENT);

			rect.setOnMouseEntered(e -> rect.setFill(Color.rgb(204, 250, 250, 0.10)));
			rect.setOnMouseExited(e -> rect.setFill(Color.TRANSPARENT));

			final int column = m;

			rect.setOnMouseClicked(e -> {
				placePiece(new Piece(redTurn), column);

				if (cpuGame) 
				{
					placeCpuPiece(new Piece(cpuGame));
				}
			});
			
			list.add(rect);
		}
		
		return list;
	}

	/**
	 * This method is used for when the computer places their piece.
	 * @param piece
	 */
	private void placeCpuPiece(Piece piece) 
	{
		int r = ROW - 1;
		Random rand = new Random();
		int col = rand.nextInt(7);

		do {
			if (!getPiece(col, r).isPresent()) 
			{
				break;
			}
			r--;
		} while (r >= 0);

		if (r < 0) 
		{
			return;
		}
	
		connect4Grid[col][r] = piece;
		cpuMoves.add(piece);

		pane.getChildren().add(piece);
		piece.setTranslateX(col * (GAME_SIZE + 6) + GAME_SIZE / 3);
		piece.setTranslateY(r * (GAME_SIZE + 6) + GAME_SIZE / 3);

		int colRow = r;
		
		if (winLogic(col, colRow)) 
		{
			gameOver();
		}

		redTurn = !redTurn;
		System.out.println((redTurn ? "BLACK Player's " : "RED Player's ") + "Turn");
	}

	/**
	 * This method is used for when a person plays their piece.
	 * @param piece
	 * @param col
	 */
	private void placePiece(Piece piece, int col) 
	{

		int r = ROW - 1;

		do {
			if (!getPiece(col, r).isPresent()) 
			{
				break;
			}
			r--;
		} while (r >= 0);

		if (r < 0) 
		{
			return;
		}
		
		connect4Grid[col][r] = piece;
		cpuMoves.add(piece);

		pane.getChildren().add(piece);
		piece.setTranslateX(col * (GAME_SIZE + 6) + GAME_SIZE / 3);
		piece.setTranslateY(r * (GAME_SIZE + 6) + GAME_SIZE / 3);

		int colRow = r;

		if (winLogic(col, colRow)) 
		{
			gameOver();
		}
		
		if (cpuGame) 
		{
			redTurn = !redTurn;
			System.out.println((redTurn ? "BLACK Player's " : "RED Player's ") + "Turn");
		} 
		
		else 
		{
			redTurn = !redTurn;
			System.out.println((redTurn ? "BLACK Player's " : "RED Player's ") + "Turn");
		}
	}

	/**
	 * This method shows the logic of how someone wins the connect 4 game.
	 * @param col
	 * @param colRow
	 * @return winnerFound
	 */
	private boolean winLogic(int col, int colRow) 
	{

		List<Point2D> colWin = IntStream.rangeClosed(colRow - 3, colRow + 3).mapToObj(r -> new Point2D(col, r))
				.collect(Collectors.toList());
		
		List<Point2D> rowWin = IntStream.rangeClosed(col - 3, col + 3).mapToObj(c -> new Point2D(c, colRow))
				.collect(Collectors.toList());

		Point2D diagonalRight = new Point2D(col - 3, colRow + 3);
		List<Point2D> rightDiaWin = IntStream.rangeClosed(0, 6).mapToObj(i -> diagonalRight.add(i, -i))
				.collect(Collectors.toList());

		Point2D diagonalLeft = new Point2D(col - 3, colRow - 3);
		List<Point2D> leftDiaWin = IntStream.rangeClosed(0, 6).mapToObj(i -> diagonalLeft.add(i, i))
				.collect(Collectors.toList());

		return winnerFound(colWin) || winnerFound(rowWin) || winnerFound(rightDiaWin) || winnerFound(leftDiaWin);
	}

	/**
	 * This method is a helper method used to determine a winner.
	 * @param slot
	 * @return true
	 */
	private boolean winnerFound(List<Point2D> section) 
	{
		int combo = 0;
		
		for (Point2D m : section) 
		{
			int col = (int) m.getX();
			int row = (int) m.getY();
			
			Piece piece = getPiece(col, row).orElse(new Piece(!redTurn));
			
			if (piece.red == redTurn) 
			{
				combo++;
				if (combo == 4) 
				{
					return true;
				}
			} 
			else 
			{
				combo = 0;
			}
		}
		return false;
	}

	/**
	 * This method is used to display the winner of the game.
	 */
	private void gameOver() 
	{
		Stage stage = new Stage();
		stage.setTitle("Winner");
		Label label = new Label("CONGRATULATIONS!");
		label.setFont(new Font("Times New Roman", 24));
		Button exit = new Button("Exit");
		VBox vpane = new VBox(8);

		if (redTurn == true) 
		{
			Label label2 = new Label("BLACK PLAYER WINS!");
			label2.setFont(new Font("Times New Roman", 24));
			vpane.getChildren().addAll(label, label2, exit);
			vpane.setAlignment(Pos.CENTER);
			exit.setOnAction(e -> {
				System.out.println("EXIT");
				System.exit(0);
			});
		} 
		
		else 
		{
			Label label3 = new Label("RED PLAYER WINS!");
			label3.setFont(new Font("Times New Roman", 24));
			vpane.getChildren().addAll(label, label3, exit);
			vpane.setAlignment(Pos.CENTER);
			exit.setOnAction(e -> {
				System.out.println("EXIT");
				System.exit(0);
			});
		}
		
		Scene scene = new Scene(vpane, 300, 150);
		stage.setScene(scene);
		stage.show();
	}

	/**
	 * returns the piece that is played.
	 * @param c
	 * @param r
	 * @return
	 */
	private Optional<Piece> getPiece(int c, int r) 
	{
		if (c < 0 || c >= COLUMN || r < 0 || r >= ROW) 
		{
			return Optional.empty();
		}
		
		return Optional.ofNullable(connect4Grid[c][r]);
	}

	/**
	 * Creates the grid with color in the window.
	 * @return rect
	 */
	private Shape createConnect4Grid() 
	{
		Shape rect = new Rectangle((COLUMN + 1) * GAME_SIZE, (ROW + 1) * GAME_SIZE);

		for (int m = 0; m < ROW; m++) 
		{
			for (int l = 0; l < COLUMN; l++) 
			{
				Circle circle = new Circle(GAME_SIZE / 2);
				circle.setCenterX(GAME_SIZE / 2);
				circle.setCenterY(GAME_SIZE / 2);
				circle.setTranslateX(l * (GAME_SIZE + 6) + GAME_SIZE / 3);
				circle.setTranslateY(m * (GAME_SIZE + 6) + GAME_SIZE / 3);

				rect = Shape.subtract(rect, circle);
			}
		}

		Light.Distant lDistant = new Light.Distant();
		lDistant.setAzimuth(45.0);
		lDistant.setElevation(30.0);

		Lighting lighting = new Lighting();
		lighting.setLight(lDistant);
		lighting.setSurfaceScale(5.0);

		rect.setFill(Color.DARKBLUE);
		rect.setEffect(lighting);
		return rect;
	}

	/**
	 * Asks user if they want to close the connect 4 game.
	 */
	private void closeGame() 
	{
		Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
		
		alert.setTitle("Exit Game");
		alert.setHeaderText("Do you want to leave the game?");
		
		ButtonType yes = new ButtonType("Yes");
		ButtonType no = new ButtonType("No");

		alert.getButtonTypes().setAll(yes, no);
		Optional<ButtonType> showOptions = alert.showAndWait();
		
		if (showOptions.get() == yes) 
		{
			Platform.exit();
		} 
		
		else if (showOptions.get() == no) 
		{
			alert.close();
		}

	}

	/**
	 * Method used to launch the game.
	 * @param mainStage
	 * @throws exception
	 */
	public void start(Stage mainStage) throws Exception 
	{
		startWindow(mainStage);
	}

	
	/**
	 * Main method used to launch the connect 4 game.
	 * @param args
	 */
	public static void main(String[] args) 
	{
		launch(args);
	}
}



