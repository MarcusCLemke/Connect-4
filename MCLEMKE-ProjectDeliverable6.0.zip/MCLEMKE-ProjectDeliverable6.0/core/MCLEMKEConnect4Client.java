package core;

import ui.MCLEMKEConnect4GUI;
import java.util.Date;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Line;
import javafx.stage.Stage;
import java.io.*;
import java.net.*;

/**
 * 
 * @author Marcus Lemke
 * 
 * class is used to show and display the connect 4 board and moves.
 *
 */
public class MCLEMKEConnect4Client extends Application implements MCLEMKEGameLogicConst
{
	private char p1piece = ' ';
	private boolean turn = false;
	private char p2piece = ' ';
	private Rack[][] rack = new Rack[6][7];
	private Label lStat = new Label();
	private Label lTitle = new Label();
	private DataInputStream getFromServer;
	private DataOutputStream sendToServer;
	private int chosenRow;
	private int chosenCol;
	private boolean continueGame = true;
	private boolean wait = true;
	private String host = "localhost";
	
	/**
	 * Starts up the connect 4 application and run the game.
	 */
	public void start(Stage primaryStage)
	{
		GridPane panel1 = new GridPane();
		
		for(int m = 0; m < 6; m++)
		{
			for(int l = 0; l < 7; l++)
			{
				panel1.add(rack[m][l] = new Rack(m, l), l, m);
			}
		}
		
		BorderPane borderPane = new BorderPane();
	    borderPane.setTop(lTitle);
	    borderPane.setCenter(panel1);
	    borderPane.setBottom(lStat);
	    
	    // Create a scene and place it in the stage
	    Scene scene = new Scene(borderPane, 320, 350);
	    primaryStage.setTitle("Connect 4 Client"); // Set the stage title
	    primaryStage.setScene(scene); // Place the scene in the stage
	    primaryStage.show(); // Display the stage
		
		serverConnection();
	}

	/**
	 * method is used to connect to the server.
	 */
	private void serverConnection()
	{
		try
		{
			Socket s = new Socket(host, 1200);
			
			getFromServer = new DataInputStream(s.getInputStream());
			sendToServer = new DataOutputStream(s.getOutputStream());
		}catch (Exception exception)
		{
			System.err.println(exception);
		}
		
	new Thread(() -> 
	{
		try
		{
			int play = getFromServer.readInt();
			
			if(play == PONE)
			{
				p1piece = 'R';
				p1piece = 'B';
			
				Platform.runLater(() ->
			{
				lTitle.setText("Player 1 is RED");
				lStat.setText("Waiting for Player 2.");
			});				
				
				getFromServer.readInt();
				
				Platform.runLater(() ->
				lStat.setText("Player 2 joined. Player starts the game first."));
				
				turn = true;
			}
			
			else if(play == PTWO)
			{
				p1piece = 'B';
				p2piece = 'R';
				
				Platform.runLater(() ->
				{
				lTitle.setText("Player 2 is BLACK");
				lStat.setText("Waiting for Player 1 to move.");
				});
			}
			
			while(continueGame)
			{
				if(play == PONE)
				{
					waitForMove();
					sendMove();
					getInfo();
				}
				
				else if(play == PTWO)
				{
					getInfo();
					waitForMove();
					sendMove();
				}
			}
		}catch(Exception exception)
		{
			System.err.println(exception);
		}
	}).start();
	}
	
	/**
	 * waits for the players move to be made.
	 * @throws InterruptedException
	 */
	private void waitForMove() throws InterruptedException
	{
		while(wait)
		{
			Thread.sleep(100);
		}
		wait = true;
	}
	
	/**
	 * sends the move that is made to the server.
	 * @throws IOException
	 */
	private void sendMove() throws IOException
	{
		sendToServer.writeInt(chosenRow);
		sendToServer.writeInt(chosenCol);
	}

	/**
	 * recieves the info from the server.
	 * @throws IOException
	 */
	private void getInfo() throws IOException
	{
		int stat = getFromServer.readInt();
		
		if(stat == PONEWIN)
		{
			continueGame = false;
			
			if(p1piece == 'R')
			{
				Platform.runLater(() ->	lStat.setText("YOU WIN! RED WINS!"));
			}
			
			else if(p1piece == 'B')
			{
				Platform.runLater(() -> lStat.setText("OTHER PLAYER WINS! RED WINS!"));
				getMove();
			}
		}
		
		if(stat == PTWOWIN)
		{
			continueGame = false;
			
			if(p1piece == 'B')
			{
				Platform.runLater(() -> lStat.setText("YOU WIN! BLACK WINS!"));			
			}
			
			else if(p1piece == 'R')
			{
				Platform.runLater(() -> lStat.setText("OTHER PLAYER WINS! BLACK WINS!"));
				getMove();
			}
		}
		
		else if(stat == TIE)
		{
			continueGame = false;
			Platform.runLater(() -> lStat.setText("THE GAME ENDS IN A DRAW!"));
		
			if(p1piece == 'B')
			{
				getMove();
			}
		}
		
		else
		{
			getMove();
			Platform.runLater(() -> lStat.setText("It is my turn!"));
			turn = true;
		}
	}
	
	/**
	 * gets the other players move.
	 * @throws IOException
	 */
	private void getMove() throws IOException
	{
		int row = getFromServer.readInt();
		int col = getFromServer.readInt();
		Platform.runLater(() -> rack[row][col].setPiece(p2piece));
	}
	

	/**
	 * class for the rack.
	 * @author marcu_000
	 *
	 */
	public class Rack extends Pane
	{
		private int col;
		private int row;
		private Rack[][] rack;
		
		private char piece = ' ';
		
		/**
		 * shows the rack.
		 * @param row
		 * @param col
		 */
		public Rack(int row, int col)
		{
			this.row = row;
			this.col = col;
			this.rack = rack;
			
			this.setPrefSize(2000, 2000);
		    setStyle("-fx-border-color: black");
		    this.setOnMouseClicked(e -> mouseClicked());
		}
		
		/**
		 * returns the piece.
		 * @return
		 */
		public char getPiece()
		{
			return piece;
		}
		
		/**
		 * sets a new piece
		 * @param p
		 */
		public void setPiece(char p)
		{
			piece = p;
			repaint();
		}
		
		/**
		 * repaints the rack and pieces.
		 */
		protected void repaint()
		{			
			if(piece == 'R')
			{
				Ellipse ellipse = new Ellipse(this.getWidth() / 2, 
				          this.getHeight() / 2, this.getWidth() / 2 - 10, 
				          this.getHeight() / 2 - 10);
				        ellipse.centerXProperty().bind(
				          this.widthProperty().divide(2));
				        ellipse.centerYProperty().bind(
				            this.heightProperty().divide(2));
				        ellipse.radiusXProperty().bind(
				            this.widthProperty().divide(2).subtract(10));        
				        ellipse.radiusYProperty().bind(
				            this.heightProperty().divide(2).subtract(10));   
				        ellipse.setStroke(Color.RED);
				        ellipse.setFill(Color.RED);
				        
				        getChildren().add(ellipse);
			}
			
			else if(piece == 'B')
			{
				Ellipse ellipse = new Ellipse(this.getWidth() / 2, 
				          this.getHeight() / 2, this.getWidth() / 2 - 10, 
				          this.getHeight() / 2 - 10);
				        ellipse.centerXProperty().bind(
				          this.widthProperty().divide(2));
				        ellipse.centerYProperty().bind(
				            this.heightProperty().divide(2));
				        ellipse.radiusXProperty().bind(
				            this.widthProperty().divide(2).subtract(10));        
				        ellipse.radiusYProperty().bind(
				            this.heightProperty().divide(2).subtract(10));   
				        ellipse.setStroke(Color.BLACK);
				        ellipse.setFill(Color.BLACK);
				        
				        getChildren().add(ellipse);
			}
		}
		
		/**
		 * handler for when the mouse is clicked.
		 */
		private void mouseClicked()
		{
			if(piece == ' ' && turn)
			{
				setPiece(p1piece);
					
				turn = false;
					
				chosenRow = row;
				chosenCol = col;
					
				lStat.setText("Waiting for other Player to move.");
					
				wait = false;
			}
		}
	}

	/**
	 * main method to run the application.
	 * @param args
	 */
	public void main(String[] args)
	{
		launch(args);	
	}
}
