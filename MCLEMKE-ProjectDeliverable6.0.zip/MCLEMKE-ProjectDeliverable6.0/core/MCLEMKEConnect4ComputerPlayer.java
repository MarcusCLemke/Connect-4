
package core;

import java.util.Random;

/**
 * @author Marcus Lemke
 * SER 216
 *
 * Description:
 * This class allows the computer to play their piece.
 */
public class MCLEMKEConnect4ComputerPlayer 
{

	/**
	 * Description:
	 * This method is how the computer decides where to put their piece.
	 * 
	 * @return
	 * Returns the random column selected through the random number generator and
	 * drops its piece there.
	 */
	public int MCLEMKEConnect4ComputerPlayerPlay() 
	{
		Random randPlacement = new Random();
		int rando = randPlacement.nextInt((7 - 1) + 1) + 1;
		return rando;
	}

}
