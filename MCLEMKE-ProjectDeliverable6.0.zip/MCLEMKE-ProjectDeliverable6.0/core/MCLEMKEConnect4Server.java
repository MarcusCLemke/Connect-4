package core;

import ui.MCLEMKEConnect4GUI;
import java.io.*;
import java.net.*;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import javafx.application.Application;
import javafx.application.Platform;
import java.awt.*;
import java.util.Date;
import java.awt.event.*;
/**
 * 
 * @author Marcus Lemke
 * 
 * Class is used to hold and maintain the server.
 *
 */
public class MCLEMKEConnect4Server extends Application implements MCLEMKEGameLogicConst 
{

	private int sessionNo = 1; // Number a session
	  
	/**
	 * Method is used to start up the connect 4 server.
	 */
	  @Override // Override the start method in the Application class
	  public void start(Stage primaryStage) {
	    TextArea taLog = new TextArea();

	    // Create a scene and place it in the stage
	    Scene scene = new Scene(new ScrollPane(taLog), 450, 200);
	    primaryStage.setTitle("Connect 4 Server"); // Set the stage title
	    primaryStage.setScene(scene); // Place the scene in the stage
	    primaryStage.show(); // Display the stage

	    new Thread( () -> {
	      try {
	        // Create a server socket
	        ServerSocket serverSocket = new ServerSocket(1200);
	        Platform.runLater(() -> taLog.appendText(new Date() +
	          ": Server started at socket 1200\n"));
	  
	        // Ready to create a session for every two players
	        while (true) {
	          Platform.runLater(() -> taLog.appendText(new Date() +
	            ": Wait for players to join session " + sessionNo + '\n'));
	  
	          // Connect to player 1
	          Socket player1 = serverSocket.accept();
	  
	          Platform.runLater(() -> {
	            taLog.appendText(new Date() + ": Player 1 joined session " 
	              + sessionNo + '\n');
	            taLog.appendText("Player 1's IP address" +
	              player1.getInetAddress().getHostAddress() + '\n');
	          });
	  
	          // Notify that the player is Player 1
	          new DataOutputStream(
	            player1.getOutputStream()).writeInt(PONE);
	  
	          // Connect to player 2
	          Socket player2 = serverSocket.accept();
	  
	          Platform.runLater(() -> {
	            taLog.appendText(new Date() +
	              ": Player 2 joined session " + sessionNo + '\n');
	            taLog.appendText("Player 2's IP address" +
	              player2.getInetAddress().getHostAddress() + '\n');
	          });
	  
	          // Notify that the player is Player 2
	          new DataOutputStream(
	            player2.getOutputStream()).writeInt(PTWO);
	  
	          // Display this session and increment session number
	          Platform.runLater(() -> 
	            taLog.appendText(new Date() + 
	              ": Start a thread for session " + sessionNo++ + '\n'));
	  
	          // Launch a new thread for this session of two players
	          new Thread(new SessHandler(player1, player2)).start();
	        }
	      }
	      catch(IOException ex) {
	        ex.printStackTrace();
	      }
	    }).start();
	  }
	
	  /**
	   * Used to handle and maintain the server.
	   */
	class SessHandler implements Runnable, MCLEMKEGameLogicConst
	{
		private Socket play1;
		private Socket play2;
		
		private char[][] rack = new char[6][7];
		
		private DataInputStream getFromPlay1;
		private DataOutputStream sentToPlay1;
		
		private DataInputStream getFromPlay2;
		private DataOutputStream sentToPlay2;
		
		private boolean continueGame = true;
		
		public SessHandler(Socket play1, Socket play2)
		{
			this.play1 = play1;
			this.play2 = play2;
			
			for(int c = 0; c < 6; c++)
			{
				for(int l = 0; l < 7; l++)
				{
					rack[c][l] = ' ';
				}
			}
		}
	
		/**
		 * Sends the move made to the server.
		 * @param out
		 * @param row
		 * @param col
		 * @throws IOException
		 */
		private void sendMoveMade(DataOutputStream out, int row, int col) throws IOException
		{
			out.writeInt(row);
			out.writeInt(col);
		}
		
		/**
		 * Determines if the rack is full.
		 * @return true if it is.
		 */
		private boolean rackIsFull()
		{
			for(int c = 0; c < 6; c++)
			{
				for(int l = 0; l < 7; l++)
				{
					if(rack[c][l] == ' ')
					{
						return false;
					}
				}
			}
			
			return true;
		}
		
		/**
		 * Checks to see if someone has won the game.
		 * @param row
		 * @param col
		 * @param piece
		 * @return if someone has.
		 */
		private boolean winnerIsFound(int row, int col, char piece)
		{
			for(int m = 0; m < 5; m++)
			{
				for(int l = 0; l < 6; l++)
				{
					System.out.println(rack[m][l]);
				}
				System.out.println();
			}
			
			for(int m = 0; m < 3; m++)
			{
				for(int l = 0; l < 7; l++)
				{
					if(rack[m][l] == piece && rack[m + 1][l] == piece && rack[m + 2][l] == piece
							&& rack[m + 3][l] == piece)
					{
						return true;
					}	
				}
			}
			
			for(int m = 0; m < 6; m++)
			{
				for(int l = 0; l < 3; l++)
				{
					if(rack[m][l] == piece && rack[m][l + 1] == piece && rack[m][l + 2] == piece
							&& rack[m][l + 3] == piece)
					{
						return true;
					}	
				}
			}
			
			for(int m = 0; m < 3; m++)
			{
				for(int l = 0; l < 7; l++)
				{
					if(rack[m][l] == piece && rack[m + 1][l + 1] == piece && rack[m + 2][l + 2] == piece
							&& rack[m + 3][l + 3] == piece)
					{
						return true;
					}	
				}
			}
			
			for(int m = 0; m < 3; m++)
			{
				for(int l = 3; l < 7; l++)
				{
					if(rack[m][l] == piece && rack[m + 1][l - 1] == piece && rack[m + 2][l - 2] == piece
							&& rack[m + 3][l -3] == piece)
					{
						return true;
					}	
				}
			}
								
			return false;
		}
		
		
		
		/**
		 * Used to communicate the moves made during the game of connect 4.
		 */
		public void run()
		{
			try
			{
			DataInputStream getFromPlay1 = new DataInputStream(play1.getInputStream());
			DataOutputStream sentToPlay1 = new DataOutputStream(play1.getOutputStream());
			
			DataInputStream getFromPlay2 = new DataInputStream(play2.getInputStream());
			DataOutputStream sentToPlay2 = new DataOutputStream(play2.getOutputStream());
			
			sentToPlay1.writeInt(1);
			
			while(true)
			{
				int row = getFromPlay1.readInt();
				int col = getFromPlay1.readInt();
				
				char piece = 'R';
				
				rack[row][col] = 'R';
				
				
				if(winnerIsFound(row, col, piece))
				{
					sentToPlay1.writeInt(PONEWIN);
					sentToPlay2.writeInt(PONEWIN);
					sendMoveMade(sentToPlay2, row, col);
					break;
				}
				
				else if(rackIsFull())
				{
					sentToPlay1.writeInt(TIE);
					sentToPlay2.writeInt(TIE);
					sendMoveMade(sentToPlay2, row, col);
					break;
				}
				
				else
				{
					sentToPlay2.writeInt(CONT);
					sendMoveMade(sentToPlay2, row, col);
				}
				
				row = getFromPlay2.readInt();
				col = getFromPlay2.readInt();
				
				if(winnerIsFound(row, col, piece))
				{
					sentToPlay1.writeInt(PTWOWIN);
					sentToPlay2.writeInt(PTWOWIN);
					sendMoveMade(sentToPlay1, row, col);
					break;
				}
				
				else
				{
					sentToPlay1.writeInt(CONT);
					sendMoveMade(sentToPlay1, row, col);
				}
			}
		}catch (IOException exception)
		{
			System.err.println(exception);
		}
	}
	}
	
	/**
	 * Launches the server.
	 * @param args
	 */
	public static void main(String[] args) 
	{
	    launch(args);
	  }
}
