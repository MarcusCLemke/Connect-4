package core;

/**
 * @author Marcus Lemke
 * SER 216
 * 
 * Description:
 * This is the program for the game logic of Connect 4.
 */
public class MCLEMKEConnect4 
{
		
		/**
		 *Description:
		 *Rack is the char variable used to create the game rack of Connect 4. 
		 */
		char [][] rack;
		
		
		/**
		 * Description:
		 * This method is used to create the rack to hold the pieces of Connect 4.
		 */
		public MCLEMKEConnect4()
		{
			rack = new char [6][7];
			
			for(int r = 0; r < rack.length; r++)
			{
				for(int co = 0; co < rack[r].length; co++)
				{
					rack[r][co] = ' ';
				}
			}
		}
		
		
		/**
		 * Description:
		 * This method is used to make sure there is a valid space left for a piece. 
		 * If there is not a valid space left the game is over.
		 * 
		 * @return
		 * returns true if there are no more playable spaces in the rack.
		 */
		public boolean gameOver()
		{
			for(int r = 0; r < rack[0].length; r++)
			{
				if(rack[0][r] == ' ')
				{
					return false;
				}
			}
			
			return true;
		}
		
		
		/**
		 * Description:
		 * This method is used to print out the shape of the rack in the console.
		 */
		public void printRack()
		{
			for(int r = 0; r < rack.length; r++)
			{
				System.out.printf("|");
				
				for(int co = 0; co < rack[r].length; co++)
				{
					System.out.printf("%c|", rack[r][co]);
				}
				
				System.out.println();
			}
			
			for(int co = 0; co < rack[0].length; co++)
			{
				System.out.printf("--");
			}
			
			System.out.println("-");
		}
		
		
		/**
		 * Description:
		 * This goes through the 4 ways to win the game and checks to see if there is a winner
		 * of the game after each turn.
		 * 
		 * @return
		 * If a winner is found then it returns true. If winner is not found returns false.
		 */
		public boolean winnerFound()
		{
			boolean colWin = false;
			boolean rowWin = false;
			boolean rightDiaWin = false;
			boolean leftDiaWin = false;	
		
			for(int row = 0; row <= 2; row++)
			{
				for(int col = 0; col <= 6; col++)
				{
					if(rack[row][col] == rack[row + 1][col] && rack[row][col] == rack[row + 2][col]
					&& rack[row][col] == rack[row + 3][col] && rack[row][col] != ' ')
					{
						colWin = true;
						break;
					}
				}
			}
		
			for(int row = 0; row <= 5; row++)
			{
				for(int col = 0; col <= 3; col++)
				{
					if(rack[row][col] == rack[row][col + 1] && rack[row][col] == rack[row][col + 2]
					&& rack[row][col] == rack[row][col + 3] && rack[row][col] != ' ')
					{
						rowWin = true;
						break;
					}
				}
			}
		
			for(int row = 0; row <= 2; row++)
			{
				for(int col = 3; col <= 6; col++)
				{
					if(rack[row][col] == rack[row + 1][col - 1] && rack[row][col] == rack[row + 2][col - 2]
					&& rack[row][col] == rack[row + 3][col - 3] && rack[row][col] != ' ')
					{
						rightDiaWin = true;
						break;
					}
				}
			}
		
			for(int row = 0; row <= 2; row++)
			{
				for(int col = 0; col <= 3; col++)
				{
					if(rack[row][col] == rack[row + 1][col + 1] && rack[row][col] == rack[row + 2][col + 2]
					&& rack[row][col] == rack[row + 3][col + 3] && rack[row][col] != ' ')
					{
						leftDiaWin = true;
						break;
					}
				}
			}
		
			if(colWin || rowWin || rightDiaWin || leftDiaWin)
			{
				return true;
			}
		
			else
			{
				return false;
			}
		
		}
		
		
		/**
		 * Description:
		 * This method looks to see if the column inputed by the user is valid.
		 * If it is valid then it drops the piece.
		 * 
		 * @param player
		 * player is used to represent the user of the program/person playing the game.
		 * 
		 * @param col
		 * col is used to represent the column the player selected to drop their piece in and is bounded by
		 * the length of the number of columns of the rack of the connect 4 game.
		 * 
		 * @return
		 * drop returns true if the players choice is valid and there is space available.
		 * If the column they chose is not valid or the column is full then drop will return false.
		 * 
		 * @exception
		 * An exception occurs when a player or computer inputs a column value that isn't on the board
		 * or that the column is already full. 
		 */
		public boolean dropPiece(char player, int col)
		{
			col--;
			
			if(col < 0 || col > 6)
			{
				throw new ArrayIndexOutOfBoundsException("Not a Valid Column");
			}
			
			boolean drop = false;
			
			for(int r = rack.length - 1; r >= 0; r--)
			{
				if(rack[r][col] == ' ')
				{
					rack[r][col] = player;
					drop = true;
					break;
				}
			}
			
			return drop;
		}
}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

