package core;
/**
 * 
 * @author Marcus Lemke
 * 
 * This is used to hold all the constants of Connect 4.
 *
 */
public interface MCLEMKEGameLogicConst 
{
	/** 
	 * Holds number of rows on the game board. 
	 */
	final static int ROW = 6;

	/** 
	 * Holds number of columns on the game board. 
	 */
	final static int COLUMN = 7;

	/** 
	 * Holds client/server prompt for player 1. 
	 */
	final static int PONE = 1;

	/** 
	 * Holds client/server prompt for player 2. 
	 */
	final static int PTWO = 2;

	/** 
	 * Hold client/server prompt if player 1 wins game. 
	 */
	final static int PONEWIN = 1;

	/** 
	 * Holds client/server prompt if player 2 wins game. 
	 */
	final static int PTWOWIN = 2;

	/** 
	 * Holds client/server prompt if the game session is a draw. 
	 */
	final static int TIE = 3;

	/** 
	 * Holds client/server prompt to continue I/O player turns 
	 */
	final static int CONT = 4;

	/** 
	 * Designate invalid move to send to client 
	 */
	final static int INVALID = 5;

	/** 
	 * Holds color and piece associated for Red and X 
	 */
	final static String RED = "X";

	/** 
	 * Holds color and piece associated for Black and O 
	 */
	final static String BLACK = "O";

	/** 
	 * Final int to set size of the game board. 
	 */
	final static int GAME_SIZE = 100;

}
