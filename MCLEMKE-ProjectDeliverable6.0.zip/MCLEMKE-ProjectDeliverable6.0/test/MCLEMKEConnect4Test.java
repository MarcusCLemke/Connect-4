package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.After;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.rules.ExpectedException;

import core.MCLEMKEConnect4;
import core.MCLEMKEConnect4ComputerPlayer;

/**
 * 
 * @author Marcus Lemke
 * 
 * Program is used to check test the coverage of the the Connect4 Logic and computer player.
 *
 */
public class MCLEMKEConnect4Test 
{

	// create the local object
	MCLEMKEConnect4 test = new MCLEMKEConnect4();
	
	public final ExpectedException exception = ExpectedException.none();

	@Test
	public void ComputerTest() 
	{
		MCLEMKEConnect4ComputerPlayer game= new MCLEMKEConnect4ComputerPlayer();
		game.MCLEMKEConnect4ComputerPlayerPlay();
	}
	
	
	/**
	 * Check for the printRack() method
	 */
	@Test
	public void printRackTest() 
	{
		test.printRack();
	}
	
	
	/**
	 * Check for the winnerFound() method
	 */
	@Test
	public void leftDiaWinner() 
	{
		test.dropPiece('X', 1);
		test.dropPiece('O', 2);
		test.dropPiece('X', 2);
		test.dropPiece('O', 3);
		test.dropPiece('X', 3);
		test.dropPiece('O', 4);
		test.dropPiece('X', 3);
		test.dropPiece('X', 4);
		test.dropPiece('O', 4);
		test.dropPiece('X', 4);
		assertEquals(true, test.winnerFound());
	}

	
	@Test
	public void rightDiaWinner() 
	{
		
		test.dropPiece('X', 4);
		test.dropPiece('O', 3);
		test.dropPiece('X', 3);
		test.dropPiece('O', 2);
		test.dropPiece('X', 1);
		test.dropPiece('O', 2);
		test.dropPiece('X', 2);
		test.dropPiece('X', 1);
		test.dropPiece('O', 1);
		test.dropPiece('X', 1);
		assertEquals(true, test.winnerFound());
	}
	
	
	@Test
	public void rowWinner() 
	{
		test.dropPiece('X', 1);
		test.dropPiece('X', 2);
		test.dropPiece('X', 3);
		test.dropPiece('X', 4);
		assertEquals(true, test.winnerFound());

	}
	
	
	@Test
	public void winnerFoundTest() 
	{
		test.dropPiece('X', 1);
		test.dropPiece('X', 1);
		test.dropPiece('X', 1);
		test.dropPiece('X', 1);

		assertEquals("Checking step of the computer: ", true,test.winnerFound());
	}

	
	/**
	 * Check for dropPieceTest(), the result is true
	 */
	@Test
	public void dropPieceTestPass() 
	{
		assertTrue("Drop():", test.dropPiece('X', 5));
	}

	
	@Test
	public void dropPieceTestFalse() 
	{
		test = new MCLEMKEConnect4();
		exception.expect(ArrayIndexOutOfBoundsException.class);
		test.dropPiece('X', 9);
	}

	
	/**
	 * Check for gameOver()
	 */
	@Test
	public void testTestConnect4() 
	{
		gameOvertest();
		doExecute();
		verify();
	}

	
	private void verify() 
	{
		assertEquals("Success", false, test.gameOver());
	}

	
	private void doExecute() 
	{
		test.gameOver();
	}

	
	private void gameOvertest() 
	{
		test = new MCLEMKEConnect4();
		test.gameOver();
	}

}
